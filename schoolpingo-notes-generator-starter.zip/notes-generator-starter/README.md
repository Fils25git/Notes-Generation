# SchoolPingo Notes Generator — Starter

## What this version does

- Shows a category modal when the page opens.
- Supports:
  - Primary Notes: P1–P6
  - Ordinary Level Notes: S1–S3
- Changes class and subject lists automatically.
- Looks for note files using this pattern:

  notes/{subject-code}/{class}_v{version}.pdf

- Checks versions 1–5 and randomly chooses one that exists.
- Adds:
  - Cover page
  - Header
  - Ownership footer
  - Page numbers
- Shows the generated PDF in a preview.
- Lets the user choose the downloaded filename.

## Run it correctly

Do not double-click `index.html`, because browsers may block local PDF fetch requests.

Open the project using VS Code Live Server:

1. Open the folder in VS Code.
2. Install the Live Server extension if needed.
3. Right-click `index.html`.
4. Choose **Open with Live Server**.

## Add your PDF notes

Examples:

notes/eng/p3_v1.pdf
notes/eng/p3_v2.pdf
notes/math/p3_v1.pdf
notes/chemistry/s1_v1.pdf

Subject folder codes:

- eng
- math
- kiny
- set
- srs
- chemistry
- biology
- history
- geography
- entrepreneurship
- physics

The system checks `_v1.pdf` through `_v5.pdf`.

## Important security note

This browser-only starter is suitable for development, but not for securely selling notes.
Files stored in a public frontend folder can be discovered and downloaded directly.

For production, note selection, payment verification, PDF branding, and final download
should happen in the Node.js/Express backend. The frontend should receive only the
generated purchased file.
